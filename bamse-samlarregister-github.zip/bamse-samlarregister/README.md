# Bamse – mitt samlarregister

En fristående webapp för att inventera Bamse-tidningar.

## Publicera med GitHub Pages

1. Skapa ett nytt GitHub-repository med namnet `bamse-samlarregister`.
2. Välj **Public** (eller kontrollera att din GitHub-plan stöder Pages för privata repos).
3. Ladda upp `index.html` till repositoryts rotmapp.
4. Öppna **Settings → Pages**.
5. Under **Build and deployment**, välj **Deploy from a branch**.
6. Välj branch `main` och mapp `/ (root)`, klicka **Save**.
7. Efter någon minut visas webbadressen under Settings → Pages.

Vanlig adress blir:
`https://DITT-GITHUB-NAMN.github.io/bamse-samlarregister/`

## Lagring

Registeruppgifterna sparas i webbläsarens `localStorage`. Det betyder att data är knuten till webbläsaren och enheten. Använd knapparna **Exportera register** och **Importera register** för säkerhetskopiering och flytt mellan enheter.

## Innehåll

- Årgångar 1973–2026
- Planerade nummer enligt startvärdena: 12/år till och med 1994, 13/år 1995–1999, 18/år 2000–2019 och 20/år från 2020
- Markera ägda nummer
- Skick, anteckningar och omslagsbild
- Årsöversikt, statistik och JSON-säkerhetskopia

**Obs:** Antalen är startvärden för inventeringen och behöver verifieras mot historiska utgivningskataloger. Appen hämtar inte automatiskt upphovsrättsskyddade omslagsbilder.
